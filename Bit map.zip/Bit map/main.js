$(document).ready(function()
{
    $("button").click(function()
    {
        $(".s-bar-menu").slideToggle(1000);
    })
})